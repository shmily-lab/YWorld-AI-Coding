# -*- coding: utf-8 -*-
"""把 SQLite 学习工作台部署到目标目录。

用法：
    python scripts/deploy_workbench.py <目标目录>
    python scripts/deploy_workbench.py D:/my-sql-lab --auto

    python scripts/deploy_workbench.py <目标目录> --check   # 只做题库自检

做了三件事：
1. 复制 assets/workbench/ 下所有文件（不含生成的 .db，它会被重新生成）
2. 调用 run.py init 依据固定随机种子重建 sandbox/learn.db
3. 调用 run.py selftest 校验全部题目的参考答案仍然有效
"""
import argparse
import os
import shutil
import subprocess
import sys

ASSETS = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                      "assets", "workbench")
SKIP_DIRS = {"__pycache__", ".git", "sessions"}


def copy_tree(src: str, dst: str) -> int:
    n = 0
    for root, dirs, files in os.walk(src):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        rel = os.path.relpath(root, src)
        for f in files:
            if f.endswith((".pyc", ".db")):
                continue
            target_dir = os.path.join(dst, rel)
            os.makedirs(target_dir, exist_ok=True)
            shutil.copy2(os.path.join(root, f), os.path.join(target_dir, f))
            n += 1
    return n


def run(cmd: list[str], cwd: str) -> int:
    print(f"$ {' '.join(cmd)}")
    return subprocess.call(cmd, cwd=cwd)


def main():
    ap = argparse.ArgumentParser(description="部署数据库学习工作台")
    ap.add_argument("target", help="目标目录")
    ap.add_argument("--check", action="store_true", help="跳过复制，只跑题库自检")
    ap.add_argument("--auto", action="store_true", help="部署后自动启动网页工作台")
    a = ap.parse_args()

    target = os.path.abspath(a.target)
    if not os.path.exists(os.path.join(target, "run.py")):
        os.makedirs(target, exist_ok=True)
        n = copy_tree(ASSETS, target)
        print(f"[OK] 已复制 {n} 个文件 -> {target}")
    else:
        print(f"[i] {target} 已存在工作台，跳过复制")

    py = sys.executable
    print("\n[1/2] 生成沙箱数据库")
    rc = run([py, "run.py", "init"], target)
    if rc != 0:
        print("数据库生成失败，请检查 Python 版本（需要 3.10+）")
        return rc

    print("\n[2/2] 题库自检")
    rc = run([py, "run.py", "selftest"], target)
    if rc != 0:
        print("\n有题目自检失败 —— 通常是数据被改过或参考答案有误，请检查。")
        return rc

    print("\n" + "=" * 56)
    print(f"部署完成：{target}")
    print("下一步：")
    print(f"  cd {target} && python run.py web        # 浏览器练习环境")
    print(f"  cd {target} && python run.py exam --stage 1   # 命令行闯关")
    print("=" * 56)

    if a.auto:
        return run([py, "run.py", "web"], target)
    return 0


if __name__ == "__main__":
    sys.exit(main())

# -*- coding: utf-8 -*-
"""校验题库文件：能不能被加载、字段是否齐全、参考答案能不能通过自己的判分规则。

用法：
    python scripts/check_bank.py <工作台目录> [阶段号]

常见用途：
- 新增/修改了 questions/stageN.py 之后自检
- 改了 sandbox/seed.py（数据分布变了）之后确认答案有没有失效
"""
import argparse
import os
import sys

REQUIRED = ("id", "stage", "title", "difficulty", "points", "prompt", "hint", "verify", "teach")
MODES = ("exact", "check", "plan")


def main():
    ap = argparse.ArgumentParser(description="题库校验")
    ap.add_argument("workbench", help="工作台目录")
    ap.add_argument("stage", nargs="?", type=int, default=None, help="只校验某个阶段")
    a = ap.parse_args()

    wb = os.path.abspath(a.workbench)
    sys.path.insert(0, wb)

    try:
        from engine.grader import grade
        from engine.loader import all_questions
    except ImportError as e:
        print(f"无法加载工作台：{e}\n确认 {wb} 下有 engine/ 和 questions/ 目录")
        return 1

    qs = all_questions()
    if a.stage:
        qs = [q for q in qs if q["stage"] == a.stage]
        print(f"只校验阶段 {a.stage}：{len(qs)} 题")

    ids, problems = set(), []
    for q in qs:
        miss = [k for k in REQUIRED if k not in q]
        if miss:
            problems.append(f"{q.get('id','?')}: 缺少字段 {miss}")
            continue
        if q["id"] in ids:
            problems.append(f"{q['id']}: 题目 ID 重复")
        ids.add(q["id"])

        mode = q["verify"].get("mode", "exact")
        if mode not in MODES:
            problems.append(f"{q['id']}: 未知判分模式 {mode}")
            continue
        if mode == "exact" and not q["verify"].get("answer"):
            problems.append(f"{q['id']}: exact 模式缺少 answer")
            continue
        if mode == "check" and not q["verify"].get("check"):
            problems.append(f"{q['id']}: check 模式缺少 check")
            continue
        if mode == "plan" and not (q["verify"].get("contains") or q["verify"].get("not_contains")):
            problems.append(f"{q['id']}: plan 模式需要 contains 或 not_contains")
            continue

        # 元数据完整性：没有标签就进不了诊断，没有思路就用不了分层提示
        if not q.get("tags"):
            problems.append(f"{q['id']}: 缺 TAGS（无法参与薄弱点诊断）")
        if not q.get("approach"):
            problems.append(f"{q['id']}: 缺 APPROACH（无法提供分层解题思路）")

        # 用参考答案跑一遍自己的判分规则
        submit = q["verify"].get("answer") or q["verify"].get("check") or ""
        r = grade(q, submit)
        if not r["ok"]:
            problems.append(f"{q['id']}: 参考答案未通过 — {r['message'][:160]}")

    total_points = sum(q.get("points", 0) for q in qs)
    if problems:
        print(f"\n发现 {len(problems)} 个问题：")
        for p in problems:
            print("  ✗", p)
        return 1

    print(f"\n[OK] {len(qs)} 题全部通过校验，合计 {total_points} 分")
    return 0


if __name__ == "__main__":
    sys.exit(main())

# 工作台架构与二次开发指南

> 面向「要修改或扩展这套工作台」的场景。只想做题的话看 `assets/workbench/README.md` 即可。

## 1. 数据流

```
sandbox/schema.sql + sandbox/seed.py
        │  run.py init（固定随机种子）
        ▼
sandbox/learn.db ──────────────── 题库基准（只读，永远不被写入）
        │
        ├─ shutil.copyfile ──→ sandbox/sessions/<会话>.db   自由练习（可写）
        └─ shutil.copyfile ──→ %TEMP%/dblab_attempts/*.db    判分沙箱（一次性）
```

三条路径互不污染。**任何场景下都不要直接写 `sandbox/learn.db`**。

## 2. 判分引擎的三种模式

### exact（结果集比对）
把参考答案和用户答案在同一个副本上各跑一遍。

- 用 `normalize_rows` 排序后构成「行多重集」再比对，所以不受返回顺序影响。
- 数值容差 `|a-b| <= max(0.005, |a|*1e-9)`。这是为了让 `ROUND(SUM(x),2)` 与裸 `SUM(x)`
  都能通过 —— 浮点末位差异是表示误差不是答案错误。
- 题目可用 `"tol": 2.0` 放大容差；`"check_columns": true` 追加列名校验。

### check（自定义校验 SQL）
先执行用户 SQL，再执行校验 SQL，取第一行第一列判定：

| 返回值 | 判定 |
|---|---|
| 字符串以 `PASS` 开头，或为 `OK`/`TRUE` | 通过 |
| 数值 `1` | 通过 |
| 其它 | 失败，整段文本作为原因 |

**关键能力：校验 SQL 里可以同时访问 `main.*`（改过之后）和 `base.*`（原始基准库）。**
`base` 是在判分前由 `_grade_check` 自动 ATTACH 的。有了它就能写「逐行比对」级断言：

```sql
SELECT CASE
  WHEN EXISTS (SELECT 1 FROM orders o JOIN base.orders b USING(order_id)
               WHERE o.status <> b.status)
    THEN 'FAIL: 改动了不该改的行'
  ELSE 'PASS'
END
```

校验 SQL 支持多条语句（只有最后一条带结果集的会被取判定值），所以可以先把测试数据
INSERT 进去再验证。

### plan（执行计划断言）
对用户最后一条 SELECT 跑 `EXPLAIN QUERY PLAN`，把 detail 列拼成文本做子串断言
（忽略大小写）。适合「必须用到某个索引」「不允许出现临时排序」这类要求。

## 3. 出题规范

```python
{
    "id": "S3-Q08", "stage": 3, "title": "标题", "difficulty": "medium", "points": 8,
    "prompt": "支持 Markdown：代码块、表格、加粗",
    "hint": "卡住时看的提示，给出方向但不给答案",
    "verify": {"mode": "exact", "answer": "SELECT ..."},
    "teach": "知识点讲解，支持 Markdown",
}
```

难度/分值的经验配比：easy 5 分、medium 8~12 分、hard 12~15 分。

写完之后**必须**跑 `python scripts/check_bank.py <工作台>`：
它会检查字段完整性、ID 唯一性，并用参考答案反向跑一遍判分规则。
「答对了却判错」是这套系统最不能容忍的 bug。

## 4. 已经踩过的坑（改动代码前先读这一段）

**① 不要依赖文件删除**
某些受限沙箱会拦截 `os.remove`，所以：
- `seed.py` 用 `db.wipe_all_tables()` 原地 DROP 全部表，而不是删文件重建；
- `db.fresh_copy()` 用「临时目录 + 按线程复用的文件名 + `shutil.copyfile` 覆盖写」，
  从不删除、也不依赖 `tempfile.mkstemp` 的清理。

**② SQLite 里 `notnull` 是保留词**
查 pragma 表值函数时必须加引号：
```sql
SELECT * FROM pragma_table_info('products') WHERE "notnull" = 1;   -- 正确
SELECT * FROM pragma_table_info('products') WHERE notnull = 1;     -- 语法错误
```

**③ `INSERT ... SELECT DISTINCT ... ON CONFLICT DO NOTHING` 无法解析**
缺少 WHERE 子句时 SQLite 解析器会报 `near "DO"`。加一个恒真的业务 WHERE 即可：
```sql
INSERT INTO dim(name) SELECT DISTINCT n FROM t WHERE n IS NOT NULL
ON CONFLICT(name) DO NOTHING;
```

**④ 多语句拆分要自己写**
`sqlite3.Cursor.execute` 不接受多语句，`executescript` 又不返回结果集。
`db.split_statements()` 手动处理了单引号/双引号/反引号转义、`--`、`/* */`。
在执行入口一律用它。

**⑤ `isolation_level=None`（autocommit）是刻意的**
否则用户手写 `BEGIN TRANSACTION` 会变成嵌套事务，教学场景讲不清楚。

**⑥ prompt / teach 字符串里不要出现裸双引号**
这些是 Python 三重引号字符串，中文正文用「」代替引号，否则整份题库加载失败。

**⑦ 执行计划的措辞随 SQLite 版本变化**
- 「用到索引」要看 **SEARCH 还是 SCAN**，不是看有没有 `USING INDEX`
- 覆盖索引输出是 `SEARCH t USING COVERING INDEX idx`，其中间多了 COVERING，
  所以断言不能写 `"USING INDEX idx"`，只能写索引名或完整带 COVERING 的文本
- 混合方向的 ORDER BY（`a ASC, b DESC`）即使有索引也会 `USE TEMP B-TREE`

## 5. 换数据库（MySQL / PostgreSQL）

执行层全部收敛在 `engine/db.py`，替换点：

| 位置 | 要改的东西 |
|---|---|
| `connect()` | 换成对应的 driver；MySQL 需 `charset=utf8mb4` |
| `fresh_copy()` | 不能用文件复制，改成 `CREATE DATABASE` + 灌种子数据 |
| `schema_info()` | 换成 `information_schema` / `pg_catalog` 查询 |
| `questions/*.py` | 全部答案按 `syllabus/SQL速查与跨库差异.md` 重写；`plan` 模式的断言串也要换成 MySQL/PG 的术语 |
| `seed.py` | 数据不变，只改写入方式 |

`plan` 模式的决策点建议先手跑一次目标库的 EXPLAIN，把真实输出的文本原样写进断言 ——
不要凭记忆写 `Using index`。

## 6. 目录约定

```
workbench/
├── run.py           CLI 总入口
├── engine/          执行 + 判分 + 进度 + 复习（核心，改动要谨慎）
├── questions/       题库，每阶段一个文件 + meta.py（标签与思路）
├── sandbox/         数据库定义与种子
├── web/             浏览器工作台（server.py + static/index.html）
├── syllabus/        学习路线与速查手册
└── progress/        做题记录 JSON（可版本管理，可多人对比）
```

## 7. 学习闭环（复习 / 错题 / 诊断 / 标记）

### 数据模型（progress.json version 2）

每个题号一条记录，字段见 `engine/progress.py::_empty()`。要点：

| 字段 | 用途 |
|---|---|
| `history` | 每次提交的时间、是否通过、SQL、错误信息（只留最近 50 条） |
| `mistakes` | 只存失败记录（最近 20 条），是错题本的数据源 |
| `solved` | 错题是否已攻克。答对时自动置 true，错题本据此移出 |
| `review_level` / `next_review` | 艾宾浩斯排期 |
| `mark` | `star` 收藏 / `flag` 易错（**立刻进复习队列**）/ `done` 已掌握 |
| `note` | 自由笔记 |
| `highlights` | 标记笔：题面里选中的原文片段 + 批注 |

`load()` 会自动把 v1 的平铺格式迁移成 v2，升级时不用手工处理。

### 间隔复习（`engine/review.py`）

```
INTERVALS = [1, 2, 4, 7, 15, 30, 60]   # 天
答对 → level+1，间隔拉长；答错 → level-1 且强制 1 天后重做
```

到期判定优先级（决定复习队列排序）：

```
错题未攻克(0) > 手动标记易错(1) > 间隔复习到期(2) > 融合题已解锁(3)
```

### 融合题（`questions/stage10.py`）

`kind="review"` + `requires=[1,2]` 表示「阶段 1、2 全部通过后解锁」。
解锁判定在 `review.review_unlocked()`，前端据此显示 🔒 并拒绝进入。
**融合题不教新语法**，只把已学知识点压进一道题里 —— 写新融合题时遵守这条。

### 薄弱点诊断

单题掌握度 `_question_quality()`：

| 情况 | 得分 |
|---|---|
| 一次做对 | 1.0 |
| 错了但后来做对 | 每多错一次扣 0.2，下限 0.4 |
| 始终没做对 | 0.3 起，每多错一次再扣 0.1，下限 0 |

标签掌握度 = 该标签下所有**已练过**题目的均值。分级：≥0.8 掌握 / ≥0.5 一般 / <0.5 薄弱。
建议项只从「薄弱 + 一般」里取前 4，且 `drill` 优先给未通过的题。

样本量太少（只练了 1 题）时结论很脆，可在 `_reason_for()` 里提示
「样本不足，建议再练两道再判断」。

### 重置语义（`engine/progress.py`）

三个粒度，CLI 是 `run.py reset --question / --stage / --all`，接口是 `POST /api/reset-progress`：

| 粒度 | 清什么 | 保留什么 |
|---|---|---|
| question | attempts / passed / mistakes / review_* | 默认保留 note、mark、highlights |
| stage | 同上，作用于该阶段全部题 | 同上 |
| all | 全部（先 `backup()` 到 progress.backup.json） | 同上 |

`hard=True` 时连 note/mark/highlights 一起清。

**默认保留笔记是刻意的**：「隔段时间重做一遍」的诉求是重练，不是把笔记删掉。
只有用户明确要求清空一切时才用 hard。

网页端两个重置按钮含义不同，别合并：
- 「重置练习库」→ `POST /api/reset`，只 `db.reset_session()` 还原数据库，**不动学习记录**
- 「重置进度」→ `POST /api/reset-progress`，只清学习记录，**不动数据库**

### 分层解题思路

`meta.APPROACH[qid]` 是 3~4 步字符串数组。前端「💡 看思路」**一次只展开一步**，
最后一步给「怎么验证结果」。CLI 对应 `run.py step <题号>`（按回车逐条展开）。
写的时候务必只说「下一个动作」，不要写出完整 SQL —— 否则这个功能就失去意义了。
